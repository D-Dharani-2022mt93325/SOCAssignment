﻿namespace BakerInventory.Model
{
    public class CakeModel
    {
        public int Id { get; set; }
        public string CakeName { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }  

    }
}
